let iconCart = document.querySelector(".icon-cart");
let closeCart = document.querySelector(".close");
let body = document.querySelector("body");
let listProductHTML = document.querySelector(".listProduct");

let listProducts = [];

iconCart.addEventListener("click", () => {
    body.classList.toggle("showCart");
});

closeCart.addEventListener("click", () => {
    body.classList.toggle("showCart");
});

const addDataToHTML = () => {
    // remove default data from HTML
    listProductHTML.innerHTML = "";

    // add new data
    if (listProducts.length > 0) {
        // if has data
        listProducts.forEach((product) => {
            let newProduct = document.createElement("div");
            newProduct.dataset.id = product.id;
            newProduct.classList.add("item");
            newProduct.innerHTML = `
                <h1>"${product.id}"</h1>
                <h2>"${product.name}"</h2>

                <div class="price">"${product.price}"</div>
                <button class="addCart">AKT�F S�PAR��</button>`;
            listProductHTML.appendChild(newProduct);
        });
    }
};

const initApp = () => {
    // get data from json
    fetch("products.json")
        .then((response) => response.json())
        .then((data) => {
            listProducts = data;
            console.log(listProducts);
            addDataToHTML(); // Call function to display products
        });
};

initApp();

